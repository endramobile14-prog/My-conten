import React from 'react';
import {AbsoluteFill, Audio, Sequence, useCurrentFrame, useVideoConfig, interpolate, spring, staticFile} from 'remotion';

const C = {ink:'#102B2A', deep:'#173D38', forest:'#245B4B', leaf:'#6F9B62', lime:'#C5D86A', sand:'#E9D9B8', cream:'#F4EBD9', rust:'#C76B45', gold:'#E6B85C', mist:'#AFC6B2'};
const scenes = [
  {start:0,end:15.5,kicker:'PENJAGA HUTAN TERAKHIR',words:['BADAK','JAWA'],accent:1,kind:'hero'},
  {start:15.5,end:32.5,kicker:'SATU-SATUNYA RUMAH',words:['HUTAN','UJUNG KULON'],accent:1,kind:'habitat'},
  {start:32.5,end:49.5,kicker:'IDENTITAS YANG UNIK',words:['SATU','CULA'],accent:1,kind:'anatomy'},
  {start:49.5,end:68.5,kicker:'ANCAMAN DIAM-DIAM',words:['RUANG','MENYEMPIT'],accent:1,kind:'threat'},
  {start:68.5,end:87.5,kicker:'UPAYA MENJAGA',words:['PERLINDUNGAN','KETAT'],accent:1,kind:'protect'},
  {start:87.5,end:103.81,kicker:'MASA DEPAN DI TANGAN KITA',words:['JANGAN','BIARKAN PUNAH'],accent:1,kind:'future'},
];

const clamp = {extrapolateLeft:'clamp', extrapolateRight:'clamp'};
const smooth = (f,a,b) => interpolate(f,[a,b],[0,1],clamp);

function Rhino({frame=0, scale=1, x=0, y=0, dark=false}) {
  const bob = Math.sin(frame/19)*5;
  const skin = dark ? '#102B2A' : '#65766A';
  return <g transform={`translate(${x} ${y+bob}) scale(${scale})`}>
    <ellipse cx="0" cy="260" rx="300" ry="34" fill="#0A201F" opacity=".23"/>
    <path d="M-238 92 Q-270 40 -220 -4 Q-155 -60 -32 -45 Q72 -62 154 -10 Q220 18 232 92 L213 206 Q190 239 151 228 L128 130 L82 132 L64 238 Q40 260 6 238 L-3 137 L-102 136 L-121 235 Q-150 253 -179 229 L-176 126 Q-218 132 -238 92Z" fill={skin}/>
    <path d="M-220 4 Q-167 -78 -53 -64 Q48 -87 135 -27 Q181 4 186 62 Q151 105 80 101 L-90 92 Q-181 89 -220 4Z" fill={dark?'#1C3B36':'#819084'}/>
    <path d="M112 -27 Q172 -60 219 -20 Q254 11 231 58 Q215 93 178 95 L145 66Z" fill={skin}/>
    <path d="M195 -9 Q226 -53 250 -74 Q248 -33 230 11Z" fill={C.sand}/>
    <path d="M202 27 Q239 24 264 45 Q242 68 212 62Z" fill={skin}/>
    <path d="M156 -47 Q179 -81 204 -68 L194 -19Z" fill="#52645A"/>
    <path d="M-180 -17 Q-198 -56 -176 -78 Q-145 -67 -143 -31Z" fill="#52645A"/>
    <circle cx="190" cy="7" r="7" fill="#F1D9A4"/><circle cx="192" cy="7" r="3" fill="#152725"/>
    <path d="M-120 105 Q-95 136 -104 220 M-65 105 Q-43 151 -58 232 M65 103 Q88 150 76 225 M145 95 Q170 140 161 219" fill="none" stroke="#43564E" strokeWidth="8" opacity=".55"/>
    <path d="M-214 32 Q-155 72 -100 53 M-176 79 Q-128 111 -84 92 M-18 -37 Q8 10 -10 53 M36 -41 Q65 5 53 51 M104 -23 Q129 13 114 51" fill="none" stroke="#A6B0A2" strokeWidth="5" opacity=".38"/>
    <path d="M-226 67 Q-250 105 -242 128" stroke={skin} strokeWidth="13" fill="none" strokeLinecap="round"/>
  </g>;
}

function Canopy({frame, density=1}) {
  return <g opacity=".95">
    {Array.from({length:11}).map((_,i)=>{const x=i*125-80; const drift=Math.sin(frame/50+i)*12; return <g key={i} transform={`translate(${x+drift} ${120+(i%3)*95})`}>
      <path d={`M0 390 Q${-50*density} 190 8 0 Q${60*density} 160 24 390`} fill="#173D38" opacity=".9"/>
      <circle cx="0" cy="-10" r={115+(i%3)*17} fill={i%2?C.forest:C.deep}/>
      <circle cx="-53" cy="-55" r="56" fill={C.leaf} opacity=".35"/>
    </g>})}
  </g>;
}

function Particles({frame}) {
  return <g>{Array.from({length:28}).map((_,i)=>{const x=(i*173)%1080; const y=((i*97-frame*.7)%1950+1950)%1950; return <circle key={i} cx={x} cy={y} r={i%4===0?4:2} fill={C.gold} opacity={.18+(i%4)*.08}/>})}</g>;
}

function SceneArt({scene,frame}) {
  const local=frame-scene.start*30;
  const enter=smooth(frame,scene.start*30,scene.start*30+45);
  const zoom=1+smooth(local,0,scene.end*30-scene.start*30)*.035;
  return <svg viewBox="0 0 1080 1920" width="100%" height="100%" style={{position:'absolute',inset:0}}>
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="0.8" y2="1"><stop stopColor={C.deep}/><stop offset=".55" stopColor={C.ink}/><stop offset="1" stopColor="#081B1C"/></linearGradient>
      <radialGradient id="glow"><stop stopColor={C.leaf} stopOpacity=".35"/><stop offset="1" stopColor={C.deep} stopOpacity="0"/></radialGradient>
      <linearGradient id="ground" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#53785A"/><stop offset="1" stopColor="#183A34"/></linearGradient>
    </defs>
    <rect width="1080" height="1920" fill="url(#bg)"/>
    <circle cx="780" cy="660" r="610" fill="url(#glow)"/>
    <g opacity=".5"><path d="M0 1230 Q240 1110 460 1220 T1080 1170 V1920 H0Z" fill="#183C35"/><path d="M0 1430 Q250 1280 500 1400 T1080 1320 V1920 H0Z" fill="url(#ground)"/></g>
    {(scene.kind==='habitat'||scene.kind==='protect'||scene.kind==='future') && <g transform={`translate(0 ${scene.kind==='habitat'?80:150})`}><Canopy frame={frame}/></g>}
    {scene.kind==='hero' && <g transform={`translate(${(1-enter)*95} ${40}) scale(${1.12})`}><Rhino frame={frame} scale={1.2} x={460} y={710}/></g>}
    {scene.kind==='habitat' && <><path d="M0 1050 Q260 880 510 1040 T1080 1000" stroke={C.mist} strokeWidth="4" opacity=".24" fill="none"/><g transform={`translate(${(1-enter)*80} 40)`}><Rhino frame={frame} scale={.88} x={490} y={920}/></g><path d="M90 1420 Q540 1280 1000 1400" stroke={C.lime} strokeWidth="3" opacity=".45" fill="none"/></>}
    {scene.kind==='anatomy' && <><g transform={`translate(${(1-enter)*120} 20) scale(1.02)`}><Rhino frame={frame} scale={1.03} x={455} y={820}/></g><path d="M790 745 L935 585 L1000 585" stroke={C.gold} strokeWidth="4" fill="none"/><circle cx="790" cy="745" r="10" fill={C.gold}/><text x="940" y="555" fill={C.cream} fontSize="25" fontWeight="700" letterSpacing="4">SATU CULA</text><path d="M340 1060 L160 1215 L80 1215" stroke={C.lime} strokeWidth="4" fill="none"/><circle cx="340" cy="1060" r="9" fill={C.lime}/><text x="80" y="1260" fill={C.cream} fontSize="22" letterSpacing="3">KULIT BERLIPAT</text></>}
    {scene.kind==='threat' && <><g opacity=".5"><path d="M0 0 L1080 1920 M1080 0 L0 1920" stroke={C.rust} strokeWidth="3"/><path d="M0 950 L1080 720 M0 1250 L1080 1020" stroke={C.rust} strokeWidth="2"/></g><g transform={`translate(${(1-enter)*70} 100)`}><Rhino frame={frame} scale={.9} x={500} y={900}/></g><g transform="translate(80 1260)"><path d="M0 0 L180 -80 L340 0 L510 -90 L680 0 L900 -100" stroke={C.rust} strokeWidth="8" fill="none" strokeDasharray="18 15"/><path d="M110 80 L250 0 M430 80 L570 0 M740 80 L880 0" stroke={C.rust} strokeWidth="5"/></g></>}
    {scene.kind==='protect' && <><g transform={`translate(${(1-enter)*75} 100)`}><Rhino frame={frame} scale={.88} x={490} y={880}/></g><path d="M540 620 L760 700 L730 980 Q680 1110 540 1170 Q400 1110 350 980 L320 700Z" fill="none" stroke={C.lime} strokeWidth="7" opacity=".8"/><path d="M435 870 L510 950 L655 790" stroke={C.gold} strokeWidth="14" fill="none" strokeLinecap="round" strokeLinejoin="round"/></>}
    {scene.kind==='future' && <><g transform={`translate(${(1-enter)*70} 80)`}><Rhino frame={frame} scale={.92} x={480} y={850}/></g><path d="M100 1370 Q540 1200 980 1370" stroke={C.lime} strokeWidth="5" fill="none"/><g fill={C.lime}>{[180,300,780,900].map((x,i)=><path key={i} d={`M${x} 1400 q-70 -80 -15 -150 q55 60 15 150`} opacity=".6"/>)}</g></>}
    <Particles frame={frame}/>
  </svg>;
}

function Subtitle({scene,frame}) {
  const inFrame=frame-scene.start*30;
  const pop=spring({frame:Math.max(0,inFrame-7),fps:30,config:{damping:16,stiffness:110,mass:.8}});
  const words=scene.words;
  return <div style={{position:'absolute',top:112,left:64,right:64,textAlign:'center',transform:`translateY(${(1-pop)*34}px) scale(${.94+pop*.06})`,opacity:interpolate(inFrame,[0,12],[0,1],clamp)}}>
    <div style={{fontFamily:'Arial, sans-serif',fontWeight:900,fontSize:68,lineHeight:1.05,letterSpacing:2,color:C.cream,textTransform:'uppercase',textShadow:'0 8px 30px rgba(0,0,0,.35)'}}>
      {words.map((w,i)=><span key={w} style={{display:'inline-block',margin:'0 10px',color:i===scene.accent?C.ink:C.cream,background:i===scene.accent?C.lime:'transparent',padding:i===scene.accent?'5px 12px':'5px 0',boxDecorationBreak:'clone'}}>{w}</span>)}
    </div>
    <div style={{marginTop:22,fontSize:19,fontWeight:700,letterSpacing:6,color:C.gold}}>{scene.kicker}</div>
    <div style={{width:120,height:4,background:C.rust,margin:'24px auto 0',transform:`scaleX(${smooth(inFrame,8,28)})`,transformOrigin:'center'}}/>
  </div>;
}

function Scene({scene}) {
  const frame=useCurrentFrame();
  const {fps}=useVideoConfig();
  const fadeIn=interpolate(frame,[0,24],[0,1],clamp);
  const fadeOut=interpolate(frame,[ (scene.end-scene.start)*fps-20,(scene.end-scene.start)*fps],[1,0],clamp);
  return <AbsoluteFill style={{opacity:Math.min(fadeIn,fadeOut)}}>
    <SceneArt scene={scene} frame={frame+scene.start*fps}/>
    <Subtitle scene={scene} frame={frame+scene.start*fps}/>
    <div style={{position:'absolute',left:64,right:64,bottom:74,display:'flex',alignItems:'center',gap:18}}>
      <div style={{height:3,background:'rgba(244,235,217,.25)',flex:1}}><div style={{height:'100%',width:`${(frame/((scene.end-scene.start)*fps))*100}%`,background:C.lime}}/></div>
      <div style={{fontFamily:'Arial',fontSize:18,color:C.cream,letterSpacing:3}}>BADAK JAWA  /  {String(scenes.indexOf(scene)+1).padStart(2,'0')}</div>
    </div>
  </AbsoluteFill>;
}

export const BadakJawa = () => {
  const {fps}=useVideoConfig();
  return <AbsoluteFill style={{background:C.ink}}>
    <Audio src={staticFile('narration.mp3')} volume={1}/>
    {scenes.map((s,i)=><Sequence key={i} from={Math.round(s.start*fps)} durationInFrames={Math.round((s.end-s.start)*fps)}><Scene scene={s}/></Sequence>)}
    <AbsoluteFill style={{pointerEvents:'none',border:'2px solid rgba(244,235,217,.12)',margin:24}}/>
  </AbsoluteFill>;
};
