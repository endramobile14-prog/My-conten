import React from 'react';
import {Composition} from 'remotion';
import {BadakJawa} from './Video';

export const FPS = 30;
export const DURATION_SECONDS = 103.81;
export const TOTAL_FRAMES = Math.ceil(DURATION_SECONDS * FPS);

export const Root = () => <Composition id="BadakJawa" component={BadakJawa} durationInFrames={TOTAL_FRAMES} fps={FPS} width={1080} height={1920} />;
