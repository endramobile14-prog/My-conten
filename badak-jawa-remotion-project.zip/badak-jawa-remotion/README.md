# BADAK JAWA — Remotion 2.5D Explainer

Project video vertikal 1080x1920, 30 fps, durasi mengikuti audio narasi (±103,81 detik). Visual dibuat dengan SVG berlapis dan animasi transformasi untuk memberi kedalaman/parallax 2.5D. Tidak memerlukan Three.js.

## Render

```bash
npm install
npx remotion render src/index.jsx BadakJawa out/badak-jawa-1080x1920.mp4 --codec h264 --crf 18 --pixel-format yuv420p
```

Audio narasi disertakan sebagai `public/narration.mp3`. Bila memindahkan audio, sesuaikan `staticFile('narration.mp3')` pada `src/Video.jsx`.

## Timeline adegan

| Timecode | Durasi | Visual | Teks atas |
|---|---:|---|---|
| 00:00–00:15.5 | 15.5s | Hero reveal badak, siluet hutan dan partikel | BADAK JAWA |
| 00:15.5–00:32.5 | 17s | Kanopi Ujung Kulon, lanskap dan badak | HUTAN UJUNG KULON |
| 00:32.5–00:49.5 | 17s | Detail anatomi, callout cula dan kulit | SATU CULA |
| 00:49.5–01:08.5 | 19s | Garis ancaman dan habitat terfragmentasi | RUANG MENYEMPIT |
| 01:08.5–01:27.5 | 19s | Perisai konservasi dan tanda perlindungan | PERLINDUNGAN KETAT |
| 01:27.5–01:43.81 | 16.31s | Badak di bawah kanopi, closing hopeful | JANGAN BIARKAN PUNAH |

## Palet warna

- Deep forest `#173D38`
- Ink green `#102B2A`
- Leaf `#6F9B62`
- Lime highlight `#C5D86A`
- Warm cream `#F4EBD9`
- Sand `#E9D9B8`
- Rust danger accent `#C76B45`
- Gold `#E6B85C`

## Catatan subtitle

Teks atas merupakan headline editorial 2–4 kata per adegan dengan satu kata/frasa di-highlight, bukan transkrip kata-per-kata. Untuk subtitle verbatim yang sinkron dengan ucapan, diperlukan transkrip narasi atau file SRT.
